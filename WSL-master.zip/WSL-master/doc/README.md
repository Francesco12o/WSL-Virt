# WSL open source documentation

Build instructions: 

```
$ pip install mkdocs mkdocs-mermaid2-plugin
$ mkdocs serve
```

You can then view the documentation at `http://127.0.0.1:8000/`.