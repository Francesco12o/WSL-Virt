# Wslg.exe

`wslg.exe` is a Windows executable that is used mostly to run graphical applications with WSL. 

Its behavior is exactly the same as [wsl.exe](wsl.exe.md) with the difference that it's a win32 application, and not a console application, which allows it to start without creating a console.
