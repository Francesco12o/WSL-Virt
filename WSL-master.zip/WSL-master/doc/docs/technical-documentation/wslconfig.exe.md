# Wslconfig.exe

`wslconfig.exe` is a Windows executable that can be used to configure WSL distributions. 