/*++

Copyright (c) Microsoft. All rights reserved.

Module Name:

    resource.h

Abstract:

    This file contains resource declarations for wslhost.exe

--*/

#define ID_ICON 1
