﻿// Copyright (C) Microsoft Corporation. All rights reserved.

using CommunityToolkit.Mvvm.ComponentModel;

namespace WslSettings.ViewModels.OOBE;

public partial class GUIAppsViewModel : ObservableRecipient
{
    public GUIAppsViewModel()
    {
    }
}