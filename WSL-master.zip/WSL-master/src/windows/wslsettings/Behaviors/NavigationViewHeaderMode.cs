﻿// Copyright (C) Microsoft Corporation. All rights reserved.

namespace WslSettings.Behaviors;

public enum NavigationViewHeaderMode
{
    Always,
    Never,
    Minimal
}
