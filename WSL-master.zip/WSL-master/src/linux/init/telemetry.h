// Copyright (C) Microsoft Corporation. All rights reserved.
#pragma once

unsigned int StartTelemetryAgent();
