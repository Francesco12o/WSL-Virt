// Copyright (C) Microsoft Corporation. All rights reserved.
#pragma once

enum Operation
{
    Create,
    Update,
    Remove
};
