// Copyright (C) Microsoft Corporation. All rights reserved.
#pragma once

class NetlinkResponse;
class NetlinkChannel;
